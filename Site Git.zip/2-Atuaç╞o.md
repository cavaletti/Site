﻿---
layout: default
title: Atuação
permalink: /2-Atuação/
---

## Serviços

Devido às diferentes necessidades de nossos clientes, nossa empresa se preparou para atender de diversas formas o mercado, sendo possível realizar atividades específicas, dentro dos segmentos atuates, a execução completa "Turn Key" de um projeto.

Dessa forma, fornecemos treinamento, consultoria, gerenciamento e execução de projetos.

## Seguimentos Atuantes:

 - Arquitetura & Paisagismo
 - Automação Industrial & Comercial
 - Engenharia Civil
 - Engenharia Elétrica
 - Engenharia de Telecomunicações

