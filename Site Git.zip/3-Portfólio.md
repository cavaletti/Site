﻿---
layout: default
title: Portfólio
permalink: /3-Portfólio/
---

#### Execução de mais de 1200 Projetos de Implantação de Estação Rádio Base (RBS) pela Ericsson Gestão de Serviços (EGS).
![](/images/egs_1.jpg) ![](/images/egs_2.jpg)

#### Projeto Elétrico completo para novo complexo do IML-SP
![](/images/iml_1.jpg) ![](/images/iml_2.jpg)

#### Realização de consultoria, homologação e projeto de Call Center pela T. H. Trading
![](/images/th_1.jpg) ![](/images/th_2.jpg)

